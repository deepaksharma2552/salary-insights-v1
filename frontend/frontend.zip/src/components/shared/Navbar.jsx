import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useContext, useState, useEffect, useRef } from 'react';
import { AuthContext } from '../../context/AuthContext';

export default function Navbar() {
  const location          = useLocation();
  const navigate          = useNavigate();
  const { user, logout }  = useContext(AuthContext);
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [dropdownOpen, setDropdownOpen]       = useState(false);
  const [salariesOpen, setSalariesOpen]       = useState(false);
  const [mobileOpen, setMobileOpen]           = useState(false);
  const dropdownRef  = useRef(null);
  const salariesRef  = useRef(null);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
      if (salariesRef.current && !salariesRef.current.contains(e.target)) {
        setSalariesOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    setDropdownOpen(false);
    setSalariesOpen(false);
    setMobileOpen(false);
  }, [location.pathname]);

  // Prevent body scroll when mobile drawer is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');
  const isActive    = (path) => location.pathname === path ? 'active' : '';

  const displayName = user
    ? (user.firstName ? `${user.firstName}${user.lastName ? ' ' + user.lastName : ''}` : user.email)
    : null;

  function handleLogout() {
    setDropdownOpen(false);
    setMobileOpen(false);
    logout();
    navigate('/');
  }

  return (
    <nav className="navbar">
      <style>{`
        .user-dropdown-menu {
          position: absolute;
          top: calc(100% + 8px);
          right: 0;
          min-width: 200px;
          background: var(--panel);
          border: 1px solid var(--border);
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.18);
          overflow: hidden;
          z-index: 200;
          animation: dropdownIn 0.15s ease;
        }
        .salaries-dropdown-menu {
          position: absolute;
          top: calc(100% + 8px);
          left: 0;
          min-width: 280px;
          background: var(--panel);
          border: 1px solid var(--border);
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.18);
          z-index: 200;
          animation: dropdownIn 0.15s ease;
          padding: 6px;
        }
        .salaries-menu-item {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 9px 10px;
          border-radius: 8px;
          text-decoration: none;
          transition: background 0.1s;
          cursor: pointer;
        }
        .salaries-menu-item:hover { background: var(--bg-3); }
        .salaries-menu-icon {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          margin-top: 1px;
        }
        .salaries-menu-label {
          font-size: 13px;
          font-weight: 600;
          color: var(--text-1);
          line-height: 1.3;
        }
        .salaries-menu-desc {
          font-size: 12px;
          color: var(--text-3);
          margin-top: 2px;
          line-height: 1.4;
        }
        .salaries-menu-divider { height: 1px; background: var(--border); margin: 4px 0; }
        @keyframes dropdownIn {
          from { opacity: 0; transform: translateY(-6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .dropdown-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 16px;
          font-size: 13px;
          color: var(--text-2);
          text-decoration: none;
          cursor: pointer;
          background: transparent;
          border: none;
          width: 100%;
          text-align: left;
          transition: background 0.12s;
          font-family: 'Inter', sans-serif;
        }
        .dropdown-item:hover { background: var(--bg-3); color: var(--text-1); }
        .dropdown-item.danger { color: var(--rose); }
        .dropdown-item.danger:hover { background: var(--rose-dim); }
        .dropdown-divider { height: 1px; background: var(--border); margin: 4px 0; }
        .dropdown-header { padding: 12px 16px 8px; border-bottom: 1px solid var(--border); }
        /* Hide desktop-only nav elements on mobile */
        @media (max-width: 768px) {
          .nav-desktop-only { display: none !important; }
          .nav-mobile-user  { display: flex !important; }
          .theme-toggle     { display: none !important; }
        }
      `}</style>

      {/* ── LOGO ── */}
      <Link to="/" className="nav-logo" style={{ textDecoration: 'none' }}>
        <style>{`
          @keyframes siOrbitSweepA { from { transform: rotate(-90deg); } to { transform: rotate(270deg); } }
          @keyframes siOrbitSweepB { from { transform: rotate(90deg);  } to { transform: rotate(450deg); } }
          @keyframes siOrbitSweepC { from { transform: rotate(30deg);  } to { transform: rotate(390deg); } }
          @keyframes siOrbitTrack  { from { transform: rotate(0deg);   } to { transform: rotate(-360deg); } }
          @keyframes siOrbitCore   { 0%,100% { transform: scale(1); } 50% { transform: scale(1.12); } }
          @keyframes siOrbitPing   { 0% { transform: scale(1); opacity: 0.5; } 100% { transform: scale(1.3); opacity: 0; } }
          @media (prefers-reduced-motion: reduce) {
            .si-sweep-a,.si-sweep-b,.si-sweep-c,.si-track,.si-core,.si-ping { animation: none !important; }
          }
        `}</style>
        <svg width="36" height="36" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle className="si-ping" cx="19" cy="19" r="18" stroke="#3b82f6" strokeWidth="0.8" fill="none"
            style={{ transformOrigin: '19px 19px', animation: 'siOrbitPing 3s ease-out infinite' }} />
          <g style={{ transformOrigin: '19px 19px', animation: 'siOrbitTrack 20s linear infinite' }}>
            <circle cx="19" cy="19" r="15" stroke="#3b82f6" strokeWidth="0.7" fill="none" opacity="0.25" strokeDasharray="2.5 2.5" />
          </g>
          <circle cx="19" cy="19" r="9" stroke="#3b82f6" strokeWidth="0.5" fill="none" opacity="0.12" strokeDasharray="1.5 2" />
          <g style={{ transformOrigin: '19px 19px', animation: 'siOrbitSweepA 6s linear infinite' }}>
            <circle cx="19" cy="4" r="2.4" fill="#3b82f6" />
          </g>
          <g style={{ transformOrigin: '19px 19px', animation: 'siOrbitSweepB 6s linear infinite' }}>
            <circle cx="19" cy="4" r="2" fill="#2563eb" />
          </g>
          <g style={{ transformOrigin: '19px 19px', animation: 'siOrbitSweepC 9s linear infinite' }}>
            <circle cx="19" cy="4" r="1.6" fill="#60a5fa" opacity="0.7" />
          </g>
          <g style={{ transformOrigin: '19px 19px', animation: 'siOrbitCore 3s ease-in-out infinite' }}>
            <circle cx="19" cy="19" r="7"   fill="#3b82f6" opacity="0.1" />
            <circle cx="19" cy="19" r="4.5" fill="#3b82f6" opacity="0.2" />
            <circle cx="19" cy="19" r="2.8" fill="#3b82f6" />
          </g>
        </svg>
        <span style={{ display: 'flex', flexDirection: 'column', gap: 1, lineHeight: 1 }}>
          <span style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--text-1)', fontFamily: 'Inter,sans-serif' }}>
            Salary<span style={{ color: '#3b82f6' }}>Insights</span>
          </span>
          <span style={{ fontSize: 8.5, fontWeight: 500, letterSpacing: '0.12em', color: '#3b82f6', fontFamily: "'IBM Plex Mono',monospace", textTransform: 'uppercase', opacity: 0.75 }}>
            360° Career Clarity
          </span>
        </span>
      </Link>

      {/* ── NAV LINKS (desktop only) ── */}
      <ul className="nav-links">
        <li><Link to="/"             className={isActive('/')}>Home</Link></li>
        <li ref={salariesRef} style={{ position: 'relative' }}
          onMouseEnter={() => setSalariesOpen(true)}
          onMouseLeave={() => setSalariesOpen(false)}
        >
          <button
            onClick={() => setSalariesOpen(o => !o)}
            style={{
              display: 'flex', alignItems: 'center', gap: 4,
              background: 'transparent', border: 'none', cursor: 'pointer',
              fontSize: 'inherit', fontFamily: 'inherit', padding: '6px 2px',
              color: ['/salaries', '/level-guide', '/benchmark'].includes(location.pathname)
                ? 'var(--text-1)' : 'var(--text-2)',
              fontWeight: ['/salaries', '/level-guide', '/benchmark'].includes(location.pathname) ? 600 : 400,
            }}
          >
            Salaries
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
              style={{ transition: 'transform 0.18s', transform: salariesOpen ? 'rotate(180deg)' : 'none', opacity: 0.6 }}>
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>

          {salariesOpen && (
            <div className="salaries-dropdown-menu">
              <Link to="/salaries" className="salaries-menu-item">
                <div className="salaries-menu-icon" style={{ background: 'rgba(59,130,246,0.1)' }}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="8" y1="13" x2="16" y2="13"/>
                    <line x1="8" y1="17" x2="13" y2="17"/>
                  </svg>
                </div>
                <div>
                  <div className="salaries-menu-label">Salary database</div>
                  <div className="salaries-menu-desc">Browse real salaries by role, company &amp; location</div>
                </div>
              </Link>
              <Link to="/salaries?tab=levels" className="salaries-menu-item">
                <div className="salaries-menu-icon" style={{ background: 'rgba(139,92,246,0.1)' }}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" strokeWidth="2">
                    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                    <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
                  </svg>
                </div>
                <div>
                  <div className="salaries-menu-label">Level guide</div>
                  <div className="salaries-menu-desc">Understand career levels across companies</div>
                </div>
              </Link>
              <Link to="/salaries?tab=benchmark" className="salaries-menu-item">
                <div className="salaries-menu-icon" style={{ background: 'rgba(16,185,129,0.1)' }}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2">
                    <line x1="18" y1="20" x2="18" y2="10"/>
                    <line x1="12" y1="20" x2="12" y2="4"/>
                    <line x1="6" y1="20" x2="6" y2="14"/>
                  </svg>
                </div>
                <div>
                  <div className="salaries-menu-label">Benchmark my offer</div>
                  <div className="salaries-menu-desc">See how your offer stacks up in the market</div>
                </div>
              </Link>
              <div className="salaries-menu-divider" />
              <Link to="/submit" className="salaries-menu-item" style={{ padding: '7px 10px' }}>
                <div style={{ fontSize: 12, color: '#3b82f6', fontWeight: 500 }}>
                  ₹ Share your salary → help the community
                </div>
              </Link>
            </div>
          )}
        </li>
        <li><Link to="/companies"    className={isActive('/companies')}>Companies</Link></li>
        <li><Link to="/dashboard"    className={isActive('/dashboard')}>Analytics</Link></li>
        <li><Link to="/opportunities" className={isActive('/opportunities')}>Opportunities</Link></li>
        {user?.role === 'ADMIN' && (
          <li><Link to="/admin" className={isActive('/admin')}>Admin</Link></li>
        )}
      </ul>

      {/* ── ACTIONS ── */}
      <div className="nav-actions">

        {/* Theme toggle — always visible */}
        <button className="theme-toggle" onClick={toggleTheme}
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? (
            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="5"/>
              <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
              <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>
          ) : (
            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
          )}
        </button>

        {/* ── DESKTOP ONLY: CTAs + user dropdown ── */}
        {user ? (
          <div className="nav-desktop-only" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Link
              to="/submit"
              style={{
                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 5,
                fontSize: 13, fontWeight: 600, padding: '7px 15px', borderRadius: 8,
                border: '2px solid #10b981', color: '#065f46', background: '#ecfdf5',
                whiteSpace: 'nowrap', transition: 'background 0.15s, border-color 0.15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = '#d1fae5'; e.currentTarget.style.borderColor = '#059669'; }}
              onMouseLeave={e => { e.currentTarget.style.background = '#ecfdf5'; e.currentTarget.style.borderColor = '#10b981'; }}
            >
              <span style={{ fontSize: 14, lineHeight: 1 }}>₹</span> Share Salary
            </Link>
            <Link
              to="/opportunities/post"
              style={{
                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 5,
                fontSize: 13, fontWeight: 600, padding: '7px 15px', borderRadius: 8,
                border: 'none', color: '#fff', background: '#1e40af',
                whiteSpace: 'nowrap', transition: 'background 0.15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = '#1e3a8a'; }}
              onMouseLeave={e => { e.currentTarget.style.background = '#1e40af'; }}
            >
              <span style={{ fontSize: 15, fontWeight: 400, lineHeight: 1 }}>+</span> Post Opportunity
            </Link>

            <div ref={dropdownRef} style={{ position: 'relative' }}>
              <button
                onClick={() => setDropdownOpen(o => !o)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  padding: '6px 12px', borderRadius: 99, cursor: 'pointer',
                  background: dropdownOpen ? 'var(--bg-3)' : 'transparent',
                  border: '1px solid var(--border)',
                  transition: 'background 0.15s',
                }}
              >
                <div style={{
                  width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
                  background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.3)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 10, fontWeight: 700, color: '#3b82f6', fontFamily: 'Inter,sans-serif',
                }}>
                  {(user.firstName?.[0] ?? user.email?.[0] ?? '?').toUpperCase()}
                </div>
                <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-1)', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {displayName}
                </span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5"
                  style={{ transition: 'transform 0.2s', transform: dropdownOpen ? 'rotate(180deg)' : 'none', flexShrink: 0 }}>
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>

              {dropdownOpen && (
                <div className="user-dropdown-menu">
                  <div className="dropdown-header">
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-1)' }}>{displayName}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2, fontFamily: "'IBM Plex Mono',monospace" }}>{user.email}</div>
                  </div>
                  <Link to="/opportunities/post" className="dropdown-item">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>
                    </svg>
                    Post Opportunity
                  </Link>
                  <Link to="/my-submissions" className="dropdown-item">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/>
                    </svg>
                    My Submissions
                  </Link>
                  <div className="dropdown-divider" />
                  <button className="dropdown-item danger" onClick={handleLogout}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                      <polyline points="16 17 21 12 16 7"/>
                      <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="nav-desktop-only" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Link to="/login"    className="btn-ghost"   style={{ textDecoration: 'none' }}>Sign in</Link>
            <Link to="/register" className="btn-primary" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>Sign up</Link>
          </div>
        )}

        {/* ── Mobile user identity — avatar + first name, mobile only ── */}
        {user && (
          <div
            className="nav-mobile-user"
            onClick={() => setMobileOpen(o => !o)}
            style={{ display: 'none', alignItems: 'center', gap: 6, cursor: 'pointer' }}
          >
            <div style={{
              width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
              background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.3)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 10, fontWeight: 700, color: '#3b82f6', fontFamily: 'Inter,sans-serif',
            }}>
              {(user.firstName?.[0] ?? user.email?.[0] ?? '?').toUpperCase()}
            </div>
            <span style={{
              fontSize: 13, fontWeight: 600, color: 'var(--text-1)',
              maxWidth: 72, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>
              {user.firstName ?? user.email?.split('@')[0]}
            </span>
          </div>
        )}

        {/* ── Hamburger — mobile only ── */}
        <button
          className="nav-hamburger"
          onClick={() => setMobileOpen(o => !o)}
          aria-label="Open navigation menu"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="3" y1="6"  x2="21" y2="6"/>
            <line x1="3" y1="12" x2="21" y2="12"/>
            <line x1="3" y1="18" x2="21" y2="18"/>
          </svg>
        </button>
      </div>

      {/* ── MOBILE DRAWER ── */}
      <div className={`mobile-nav-overlay${mobileOpen ? ' open' : ''}`} onClick={() => setMobileOpen(false)} />
      <div className={`mobile-nav-drawer${mobileOpen ? ' open' : ''}`} style={{ display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
        <div className="mobile-nav-header">
          <Link to="/" className="nav-logo" style={{ textDecoration: 'none' }} onClick={() => setMobileOpen(false)}>
            <span style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--text-1)' }}>
              Salary<span style={{ color: '#3b82f6' }}>Insights</span>
            </span>
          </Link>
          <button className="mobile-nav-close" onClick={() => setMobileOpen(false)}>✕</button>
        </div>

        <ul className="mobile-nav-links">
          <li><Link to="/"              className={isActive('/')}>🏠 Home</Link></li>
          <li><Link to="/salaries"      className={isActive('/salaries')}>💰 Salary database</Link></li>
          <li><Link to="/salaries?tab=levels"    className={location.search.includes('tab=levels') ? 'active' : ''}>🗂 Level guide</Link></li>
          <li><Link to="/salaries?tab=benchmark" className={location.search.includes('tab=benchmark') ? 'active' : ''}>📊 Benchmark my offer</Link></li>
          <li><Link to="/companies"     className={isActive('/companies')}>🏢 Companies</Link></li>
          <li><Link to="/dashboard"     className={isActive('/dashboard')}>📊 Analytics</Link></li>
          <li><Link to="/opportunities" className={isActive('/opportunities')}>🎯 Opportunities</Link></li>
          {user?.role === 'ADMIN' && (
            <li><Link to="/admin" className={isActive('/admin')}>⚙️ Admin</Link></li>
          )}
        </ul>

        <div className="mobile-nav-actions">
          {user ? (
            <>
              <Link to="/submit" style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                padding: '10px 16px', borderRadius: 8, fontSize: 14, fontWeight: 600,
                border: '2px solid #10b981', color: '#065f46', background: '#ecfdf5',
                textDecoration: 'none',
              }}>
                ₹ Share Salary
              </Link>
              <Link to="/opportunities/post" style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                padding: '10px 16px', borderRadius: 8, fontSize: 14, fontWeight: 600,
                border: 'none', color: '#fff', background: '#1e40af', textDecoration: 'none',
              }}>
                + Post Opportunity
              </Link>
              <div style={{ borderTop: '1px solid var(--border)', paddingTop: 12, marginTop: 4 }}>
                <div style={{ fontSize: 12, color: 'var(--text-3)', padding: '0 12px 8px' }}>{displayName}</div>
                <Link to="/my-submissions" style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '10px 12px', borderRadius: 8,
                  fontSize: 13, fontWeight: 500, color: 'var(--text-1)',
                  background: 'transparent', border: '1px solid var(--border)',
                  textDecoration: 'none', marginBottom: 8, boxSizing: 'border-box',
                }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/>
                  </svg>
                  My Submissions
                </Link>
                <button onClick={handleLogout} style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '10px 12px', borderRadius: 8,
                  fontSize: 13, fontWeight: 500, color: 'var(--rose)',
                  background: 'transparent', border: '1px solid var(--border)',
                  cursor: 'pointer', fontFamily: 'Inter,sans-serif',
                }}>
                  Sign out
                </button>
              </div>
            </>
          ) : (
            <>
              <Link to="/login"    style={{ display:'block', padding:'10px 16px', borderRadius:8, fontSize:14, fontWeight:600, color:'var(--text-1)', background:'var(--bg-3)', border:'1px solid var(--border)', textDecoration:'none', textAlign:'center' }}>Sign in</Link>
              <Link to="/register" style={{ display:'block', padding:'10px 16px', borderRadius:8, fontSize:14, fontWeight:600, color:'white', background:'#3b82f6', textDecoration:'none', textAlign:'center' }}>Sign up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
